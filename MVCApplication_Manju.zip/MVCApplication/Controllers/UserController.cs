﻿using MVCApplication.Models;
using MVCApplication.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace MVCApplication.Controllers
{
    public class UserController : Controller
    {
        private AddWebEntities db = new AddWebEntities();
        public ActionResult UserList()
        {
            return View(db.Users.ToList());
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(UserModel user)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    User usermodel = new User();
                    // TODO: Add insert logic here  
                    usermodel.FirstName = user.FirstName;
                    usermodel.LastName = user.LastName;
                    usermodel.EmailID = user.EmailId;
                    usermodel.Address = user.Address;
                    usermodel.DOB = user.DOB;
                    db.Users.Add(usermodel);
                    db.SaveChanges();
                    ModelState.Clear();
                    return View();
                }
                
            }

            catch (DbEntityValidationException e)
            {
                var newException = new FormattedDbEntityValidationException(e);
                throw e;
            }
            return View(user);
        }


        public ActionResult Edit(int id)
        {
          
            User Users = db.Users.Find(id);
            if (Users == null)
            {
                return HttpNotFound();
            }
            return View(Users);
        }

 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,EmailID,Address,DOB")] User user)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(user);
        }


        // GET: User/Delete/
        public ActionResult Delete(int id)
        {
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: User/Delete/
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            User user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }

}
